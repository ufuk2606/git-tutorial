

function ekranaYaz(pText){
    let output = document.getElementById("output");
    output.innerHTML =  pText;
}

