

function ekranaYazdir(bilgi) {
    
let ekran = document.getElementById("ekran");

ekran.innerHTML += bilgi ;

}