
let x = 5214785369;


let sayi1 = new SayiOkuma(x);


console.log("Girilen Sayi= ", x ,"Sonuc= ", sayi1.girilenSayi());
