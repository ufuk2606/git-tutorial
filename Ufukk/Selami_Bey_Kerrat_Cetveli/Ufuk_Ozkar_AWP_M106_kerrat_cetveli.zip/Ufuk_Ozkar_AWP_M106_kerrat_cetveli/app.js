
let dom = new DOM();
let kisi = new Kisi();
let manager = new Manager();

manager.start(); 