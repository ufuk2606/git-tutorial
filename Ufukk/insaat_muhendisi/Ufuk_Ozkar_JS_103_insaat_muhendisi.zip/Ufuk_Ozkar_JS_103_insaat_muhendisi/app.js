

let daireA = daireAlan(2);
console.log("Dairenin Alanı = " , daireA);


let dikdortgenA = dikdortgenAlan(2, 5);
console.log("Dikdortgenin Alanı = " , dikdortgenA);


let daireC = daireCevre(2);
console.log("Dairenin Cevresi = " ,daireC);


let dikdortgenC = dikdortgenCevre (2,3) ;
console.log("Dikdortgenin Cevresi = " ,dikdortgenC);


let kupH = kupHacim(3);
console.log("Kupun Hacmi = " ,kupH);


let kupA = kupAlan (3);
console.log("Kupun Alani = " ,kupA);
 

