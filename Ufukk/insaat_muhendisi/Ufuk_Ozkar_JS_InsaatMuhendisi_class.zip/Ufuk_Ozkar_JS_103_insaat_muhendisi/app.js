

let daireA = InsaatMuhendisi.daireAlan(3);
output("Dairenin Alanı = " + daireA);


let dikdortgenA =InsaatMuhendisi.dikdortgenAlan(2, 5);
output("<br>Dikdortgenin Alanı = " + dikdortgenA);


let daireC = InsaatMuhendisi.daireCevre(2);
output("<br>Dairenin Cevresi = " + daireC);


let dikdortgenC = InsaatMuhendisi.dikdortgenCevre (2,3) ;
output("<br>Dikdortgenin Cevresi = " + dikdortgenC);


let kupH = InsaatMuhendisi.kupHacim(3);
output("<br>Kupun Hacmi = " + kupH);


let kupA = InsaatMuhendisi.kupAlan (3);
output("<br>Kupun Alani = "  + kupA);
 

