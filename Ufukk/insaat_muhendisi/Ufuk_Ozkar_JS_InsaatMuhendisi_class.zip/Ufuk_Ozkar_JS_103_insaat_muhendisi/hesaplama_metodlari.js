 
class InsaatMuhendisi{

    
static daireAlan(r) {
    let sayi = Math. round(Math.PI)  * Math.pow(r, 2);
    return sayi;
};


static dikdortgenAlan(a, b) {
    let sayi = a * b;
    return sayi;
};


static daireCevre(r) {
    let sayi = 2 * Math. round(Math.PI) * r;
    return sayi;
};


static dikdortgenCevre(a, b) {
    let sayi = 2 * (a + b);
    return sayi;
};


static kupHacim(x) {
    let sayi = Math.pow(x,3);
    return sayi;
};


static kupAlan(x) {
    let sayi = 6 * Math.pow(x,2);
    return sayi;
};
}






