

function output(data) {
    let ekran = document.getElementById("ekran");
    ekran.innerHTML += data ;
}