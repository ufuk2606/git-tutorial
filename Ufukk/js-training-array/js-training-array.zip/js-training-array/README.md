# JS-Training
## Arrays

You find here some simple examples and edge cases to learn the js-basics better.
Feel free to give feedback for extending this training.

### Please fix all problems in the javascript files
Firstly, open your console.
In your console, you see all the examples are failing. You are expected to correct all the problems in the folder "js/app.js"
    
