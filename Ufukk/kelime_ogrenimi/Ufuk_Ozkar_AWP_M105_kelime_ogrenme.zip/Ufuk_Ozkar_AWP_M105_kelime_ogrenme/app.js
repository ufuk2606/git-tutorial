/**
 * Array liste olusturulacak.Almanca kelimeler olacak.
 * Bir liste daha olacak Turkce karsiliklari olacak
 * Bu ikisi bir clss ta tutulacak
 * Listeden bir kelime random bir sekilde innerHTML sine yazilacak
 * Ve altinda 4 tane cevap sikki.Siklar rastgele yerlestirilecek
 * Bunlari <li> seklinde yazarsak vu <ul> ye EventListener eklersek iyi olur
 * Bu listelere tiklandiginda butun cevaplar gozukecek. Dogru sayisi ve Yanlis Sayisi guncellenecek.
 * bir buton koyup sonraki kelimeye ilerle. 
 */

almancaKelimeyiYazdir();

/**
 * class modellemeye biraz kafa yordum. Zaten onu da tam yapamadim. CSS e vakit kalmadi. 
 * Hic gondermemektense yarim halini gondermek istedim. 
 * Ama burada yazdigim gibi konustugum gibi kodlari yazamiyorum. Problemler cikiyor. 
 */