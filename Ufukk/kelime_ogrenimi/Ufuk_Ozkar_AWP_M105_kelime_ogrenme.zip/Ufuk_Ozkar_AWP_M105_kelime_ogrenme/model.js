class AlmancaTurkceKelimeler{
    constructor(almancaKelimeler, turkceKelimeler){
        this.almancaKelime = almancaKelimeler;
        this.turkceKelime = turkceKelimeler;
    }
}

const almancaKelimeler = [ "sitzen", "schreiben", "schule", "fenster", "schrank", "öffnen", "ruhig", "telefonieren", "verstehen", "allein" ] ;
const turkceKelimeler = [ "oturmak", "yazmak", "okul", "pencere", "dolap", "acmak", "sessiz-sakin", "telefon etmek", "anlamak", "yalniz" ] ;

let degerlerinGozukmesiIcinOlanListe = [] ;